/*
Authors: Joshua Roasa, Jazon Andes
Date: 12/01/2020
Description: This class displays the location and the time. It also ask user at which location they'd like to book their appointment.
*/
import java.util.Scanner;
public class Location{
public Location(){
}
public void showLocation(){ // Array List of available location
String location[] = {"Jersey City", "Newark", "Trenton", "Woodbridge Township", "Piscataway"};
String lowerLoc = String.join(",",location).toLowerCase();
Scanner scnr = new Scanner(System.in);
	String choice;
	System.out.print("We are located in ");
	if (location.length >= 1) {
		System.out.print(location[0]);
	}
	for (int i = 1; i < location.length - 1; i++) {
		System.out.print(", " + location[i]);
		if (i == location.length - 2) {
			i++;
			System.out.print(", and " + location[i] + ". ");
		}
	}
	while (true) {
		System.out.println("Please choose a location: ");
		String loc = scnr.nextLine().toLowerCase();
		while (lowerLoc.contains(loc) == false) {
			System.out.println("Please input a valid location.");
			loc = scnr.nextLine().toLowerCase();
		}
		if (lowerLoc.contains(loc) == true) {
			switch(loc) {
			case "jersey city" :
				System.out.print("ADDRESS: ");
				System.out.println("837 Manila St, Jersey City 07032");
				DisplayDateTime();
				break;
			case "newark" : 
				System.out.print("ADDRESS: ");
				System.out.println("842 Makati St, Newark 07925");
				DisplayDateTime();
				break;
			case "trenton" : 
				System.out.print("ADDRESS: ");
				System.out.println("946 Calamba Dr, Trenton 07737");
				DisplayDateTime();
				break;
			case "woodbridge township" : 
				System.out.print("ADDRESS: ");
				System.out.println("436 Laguna Ct, Woodbridge Township 07648");
				DisplayDateTime();
				break;
			case "piscataway" : 
				System.out.print("ADDRESS: ");
				System.out.println("743 Quezon Ave, Piscataway 07236");
				DisplayDateTime();
				break;
			}
		}
		System.out.println("Would you like to book your appointment here? Yes or No");
		choice = scnr.nextLine();
		choice = choice.toLowerCase();
		if (choice.equals("yes")){
			System.out.print("Thank you for choosing our company, your appointment will be at");
			String splitAdd[] = loc.split("\\s+");
			for (int i = 0; i < splitAdd.length; i++) {
				splitAdd[i] = splitAdd[i].substring(0,1).toUpperCase() + splitAdd[i].substring(1);
				System.out.print(" " + splitAdd[i]);
			}

		System.out.println(". \nPlease proceed to the next step.");
		scnr.close();
		System.exit(0);
		}
	}
}
public static void DisplayDateTime() {
	System.out.println("Mon - Fri Open: 7:30 AM - 9:30 PM");
	System.out.println("Sat - Sun Open: 8:30 AM - 6:00 PM");
}
}