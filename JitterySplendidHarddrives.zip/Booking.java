/*
Author: 
Date: 12/01/2020
Description: 
Tri Chau: added 12/7/2020
*/
import java.util.Scanner;
import java.util.ArrayList;
import java.util.regex.*;


public class Booking {
  private static final String regex = "^(.+)@(.+)$";
  private static final String regexChar = "[a-zA-Z]";
  private static final String regexNum =  "[0-9]";
	String name;
	String address;
	String problemDesc;
	String number;
	String email;
	String instructions;
	
  ArrayList<Client> arrayList = new ArrayList<>();
  
	static Scanner sc = new Scanner(System.in);
 
	public void Booking() {

	}
	public void addClient(){
    Client client = new Client();
    this.name = cName();
		this.address = cAddress();
		this.problemDesc = cProblemDesc();
		this.number = cNumber();
		this.email = cEmail();
    System.out.println("Do you have any instructions we should know?(yes/no)");
		String choice = sc.nextLine();
    choice = choice.toLowerCase();

		if(choice.equals("yes")) {
			this.instructions = cInstructions();

		}else if(choice.equals("no")) {
		  System.out.println("Thank you " + this.name + " for filling out the application!");

    }else{

      System.out.println("Invalid Command!");
		  System.out.println("Thank you " + this.name + " for filling out the application!");
    }
    client.setName(this.name);
    client.setAddress(this.address);
    client.setEmail(this.email);
    client.setProblemDesc(this.problemDesc);
    client.setNumber(this.number);
    client.setInstructions(this.instructions);
    // add to arraylist
    arrayList.add(client);
    
  }
  public void print(){
    if (arrayList.size() == 0) {
      System.out.println("No Appointment");
    }else{
      for (Client client : arrayList){
        System.out.println(client.toString());
      }
    }
  }
  public void delete(){
    if (arrayList.size() == 0){
        System.out.println("No Appointment ");

    }else{
        System.out.println("Enter your name to delete your Appointment:");
        String user =  sc.nextLine();
        for (int i =0; i <= arrayList.size(); i++){
          if(arrayList.get(i).getName().equals(user)){
            arrayList.remove(i);
            System.out.println ( "deleted successfully!");
          return;
          }
        }
    }
  }
  public void edit(){
    if (arrayList.size() == 0){
        System.out.println("No Appointment ");

    }else{
        System.out.println("Enter your name to edit your Appointment:");
        String user =  sc.nextLine();
        for (int i =0; i <= arrayList.size(); i++){
          if(arrayList.get(i).getName().equals(user)){
            arrayList.get(i).setName(cName());
            arrayList.get(i).setAddress(cAddress());
            arrayList.get(i).setEmail(cEmail());
            arrayList.get(i).setProblemDesc(cProblemDesc());
            arrayList.get(i).setNumber(cNumber());
            arrayList.get(i).setInstructions(cInstructions());
            // add to arraylist
            //arrayList.add(client);
            System.out.println ( "Edit successfully!");
            return;
          }
        }
    }
  }
	String cName() {
    String value;
		System.out.println("Enter your full name: ");
    value = sc.nextLine();
    return value;
	}
	
	String cAddress() {
		String value;
		System.out.println("Enter the address where problem is located: ");
    value = sc.nextLine();
    return value;
	}
	
	String cProblemDesc() {
		String value;
		System.out.println("Enter a brief description about your problem: ");
     value = sc.nextLine();
    return value;
		
	}
	
	String cNumber() {
    String value;
		System.out.println("Enter your number no dashes included (format: [0-9])");
    value = sc.nextLine();
    return value;
	}
	
	String cEmail() {
    String value;
    while(true){
		System.out.println("Enter your email: (format: XXX@XXX.XXX");
    Pattern pattern = Pattern.compile(regex);
    value = sc.nextLine();
    Matcher matcher = pattern.matcher(value);
    if (matcher.matches())
      break;
    }
		return value;
	}
	
	String cInstructions() {
		String value;
		System.out.println("Enter any instructions you have: ");
    value = sc.nextLine();
    return value;
	}



}
