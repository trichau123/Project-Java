/*
Author: Tri Chau
Date: 12/01/2020
Description: Calling out each class
Schedule
1 booking an appointment
2 edit an appointment
3 delete an appointment

Classes and Methods: (add as necessary)
Booking
Availability
Tasks
Tools
Client
Location (Dispatch)
Main

*/
import java.util.*;

//import Appointment;
public class Main { 
  public static void main(String[] args){

//    public class Appointment;
//    public class Booking;
//    public class location;
//    public class Task;

  String[] arr  = {};
  Booking bk = new Booking();
  boolean bl = true;
    while(bl){
    Scanner sc = new Scanner(System.in);
    System.out.println("Welcome to the booking system ");
    System.out.println("\nPlease enter your option number");
    System.out.println("1 Display all appointment available");
    System.out.println("2 Book your appointment ");
    System.out.println("3 Edit your appointment ");
    System.out.println("4 Delete your apppointment ");
    System.out.println("5 Display your apppointment: ");
    System.out.println("######################################## ");
    int a = sc.nextInt();
      switch(a){
        case 1:
          System.out.println("Display Appointment Availability ");
          Location lc = new Location();
          lc.showLocation();
          break;
        case 2:
          System.out.println("Filling information to Booking an Appointment ");
          bk.addClient();
          break;
        case 3:
          System.out.println("Edit 3: ");
          bk.edit();
          break;
        case 4:
          bk.delete();
          break;
        case 5:
          bk.print();;

          break;
        default:
          System.out.println("Good Luck!!");
          bl = false;
          break;
      }
    }
  }
}