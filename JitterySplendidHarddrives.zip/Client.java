/*
Author: Tri Chau
Date: 12/01/2020
Description: 
*/
public class Client{
  private String name;
	private String address;
	private String problemDesc;
	private String number;
	private String email;
	private String instructions;
  public Client(){}
  public Client(String name){}
  public Client(String name,String address, String problemDesc, String number, String email, String instructions){
    this.name = name;
    this.address = address;
    this.problemDesc = problemDesc;
    this.number = number;
    this.email = email;
    this.instructions = instructions;
  }
  public String getName(){
    return name;
  }
  public void setName(String name){
    this.name = name;
  }

  public String getAddress(){
    return address;
  }
  public void setAddress(String address){
    this.address = address;
  }

  public String getProblemDesc(){
    return problemDesc;
  }
  public void setProblemDesc(String problemDesc){
    this.problemDesc = problemDesc;
  }

    public String getNumber(){
    return number;
  }
  public void setNumber(String number){
    this.number = number;
  }

    public String getEmail(){
    return email; 
  }
  public void setEmail(String email){
    this.email = email;
  }
  
  public String getInstructions(){
    return instructions; 
  }
  public void setInstructions(String instructions){
    this.instructions = instructions;
  }
  
  @Override
  public String toString(){
    return "@@@@@@@@@@@@@@@@@@@@\nClient information: " + "\nName = " + name +"\nAddress = "+address+
    "\n Problem = " + problemDesc + "\n Phone Number = " +number+
    "\nEmail = "+email+"\nInstructions = "+ instructions; 
  }

}