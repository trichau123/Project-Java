// 
//Author: tri.chau@owl.ucc.edu (9084256583)
//Date: 12/01/2020
//Description:  get the time of client appointment  and check if that appointment avilable
public class Appointment{
  String time;
  boolean availability;

  public Appointment(String time, boolean availability){
    this.time = time;
    this.availability = availability;
  }

  public void setTime(String time){
    this.time = time;
  }

  public String getTime (){
      return time;
  }

  public void setAvailability(boolean availability){
    this.availability = availability;
  }

  public boolean getAvailability (){
      return availability;
  }
}